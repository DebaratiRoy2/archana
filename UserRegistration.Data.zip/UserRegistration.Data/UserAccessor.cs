﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using UserRegistration.Entity;

namespace UserRegistration.Data
{
    public class UserAccessor
    {
        private FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();
        public IQueryable<User> GetUsers()
        {
            return db.Users;
        }

        //GET: api/Users1/5
        [ResponseType(typeof(User))]
        public async Task<User> GetUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user != null)
            {
                return user;
            }
            else
                return null;
        }
        // PUT: api/Users
        [ResponseType(typeof(User))]
        public async Task<int> PutUser( User user)

        {
            int result=0;
            User us = (from u in db.Users
                      where u.UserId == user.UserId
                      select u).SingleOrDefault();
            us.Name= user.Name;
            us.password = user.password;
            us.email = user.email;
            us.Phone_number = user.Phone_number;
            result=await db.SaveChangesAsync();
            
            //catch (DbUpdateConcurrencyException)
            //{
            //    if (!UserExists(id))
            //    {
            //        throw new Exception("User does not exists!!");
            //    }
            //    else
            //    {
            //        throw new Exception("Error");
            //    }
            //}

            return result;
        }
        private bool UserExists(int id)
        {
            return db.Users.Count(e => e.UserId == id) > 0;
        }
    }
}



//  }
//public async Task<IHttpActionResult> PostUser(User user)
//{
//    if (!ModelState.IsValid)
//    {
//        return BadRequest(ModelState);
//    }

//    db.Users.Add(user);
//    await db.SaveChangesAsync();

//    return CreatedAtRoute("DefaultApi", new { id = user.UserId }, user);

//}
//}
//}
