﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserRegistration.Data;
using UserRegistration.Entity;
using System.Security.Cryptography;

namespace UserRegistration.Business
{

    public class UserManager
    {
        private readonly UserAccessor userAccessor = new UserAccessor();
        public async Task<User> GetUserDetails(int id)
        {
            return await userAccessor.GetUser(id);
        }
        public async Task<int> PutUser(User user)
        {
            return await userAccessor.PutUser(user);
        }
    }
}
